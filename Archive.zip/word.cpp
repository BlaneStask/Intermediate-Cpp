#include <iostream>
#include <cassert>
#include <string>
#include "word.h"

using namespace std;

// Precondition:
// Postcondition: the integer returned indicates where letter appears in target string,
//                with the least significant bit set if letter appears in the last
//                position in the string, the second least significant bit set if
//                letter appears in the second to last position in the string, etc
int secret::get_mask(char letter) {
    int retval = 0;
    for (int i = 0; i < word.length(); i++) {
        retval = retval * 2;
        if (word[i] == letter) {
            retval++;
        }
    }
    return retval;
}

// Precondition: word and mask are of the same length, and mask either has
//               the same contents as word, or a ? where it differs from word
// Postcondition: wherever letter appears in word, the ? in mask will be updated
//               with letter
void secret::update_mask(char letter) {
    assert(word.length() == mask.length());
    for (int i = 0; i < word.length(); i++) {
        assert(word[i] == mask[i] || mask[i] == '?');
    }
    int set_points = secret::get_mask(letter);

    int n = mask.length() - 1;
    while (set_points > 0) {
        if (set_points % 2 == 1) {
            mask[n] = word[n];
        }
        n--;
        set_points /= 2;
    }
}

secret::secret(string mask){
    word = mask;
    for(int i = 0; i < word.size(); i++){
            mask += '?';
    }
    assert(word.length() == mask.length());
}

