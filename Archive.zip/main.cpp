// Blane Stasiewicz
// CMPSC122 HW3

#include "word.h"

using namespace std;

int main(){
    //makes a copy of the class
    secret(copy);
    //tests
    assert(copy.get_mask('h') == 16);
    assert(copy.get_mask('e') == 8);
    assert(copy.get_mask('l') == 6);
    assert(copy.get_mask('o') == 1);
    assert(copy.get_mask('a') == 0);
    assert(copy.get_mask('3') == 0);
    assert(!copy.is_guess());
    copy.update_mask('h');
    assert(!copy.is_guess());

    return 0;
}


