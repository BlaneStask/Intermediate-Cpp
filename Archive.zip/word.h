#ifndef WORD_H
#define WORD_H
#include <string>
#include <cassert>

using namespace std;

class secret{
        private:
                string word;
                string mask;
        public:
                inline secret(){
                        word = "hello";
                        mask = "?????";
                }
                secret(string);
                int get_mask(char letter);
                void update_mask(char letter);
                inline bool is_guess(){
                        assert(word.length() == mask.length());
                        return word == mask;
                }
};
#endif
